#include <iostream>
using namespace std;
#define N 3
int main( int argn , char * argv[])
  {
  //const int N=3; // modo 2 di definire la costante
  double a1 [ N ];
  double a2 [ N ];
  double asomma[ N ];
  int i; // intero da usare per il ciclo attorno all'array
  i=0;
  
  cout << "dammi il valore # "<< i+1  ; cin >> a1[i];
  i=i+1;
  cout << "dammi il valore # "<< i+1  ; cin >> a1[i];
  i=i+1;
  cout << "dammi il valore # "<< i+1  ; cin >> a1[i];
  i=i+1;
  cout << "dammi il valore # "<< i+1  ; cin >> a1[i];
  i=i+1;
  cout << "dammi il valore # "<< i+1  ; cin >> a1[i];
  }
