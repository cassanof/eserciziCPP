#include <iostream>
#include <iomanip>
using namespace std;
#define N 3
int main( int argn , char * argv[])
  {
  //const int N=3; // modo 2 di definire la costante
  double a1 [ N ];     // 1 5 
  double a2 [ N ];     // 3 1 3
  double asomma[ N ];  // 4 6 ? 
  int i; // intero da usare per il ciclo attorno all'array
  i=0;
  cout << "valori di array 1"<<endl;
  /// fai per N volte
  for (/* i=0 */   ;i<N; /*  i=i+1; */  )
    {
    cout << "dammi il valore # "<< i+1<<" "  ; cin >> a1[i];
    i++;
    }
  cout << "valori di array 2\n";
  for ( i=0    ;i<N;  i=i+1  )
    {
    cout << "dammi il valore # "<< i+1<<" "  ; cin >> a2[i];
    //i=i+1;
    }
  i=0;
  while (i<N)  
    {
    asomma[i] = a1[i] + a2[i] ;
    //asomma = a1 + a2 
    i+=1;
    }
  i=0;
  do
    {
    cout << "la somma di"<<setw(7)<<a1[i]<<" e"<<setw(6)<<a2[i]<<"   e'"<<setw(5)<<asomma[i]<< endl;
    i=i+1;    
    }while (i<N);
   }
